Ext.define('HclExtLib.Application', {
    name: 'HclExtLib',

    extend: 'Ext.app.Application',

    views: [
        // TODO: add views here
    ],

    controllers: [
        // TODO: add controllers here
    ],

    stores: [
       'Companies'
    ]
});
