Ext.define('HclExtLib.controller.Main', {
    extend: 'Ext.app.Controller'
});
